#include "dbg.h"
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <libxml/xmlschemas.h>
#include <libxml/tree.h>
#include <ctype.h>
#include "sap2ism.h"

char *query_insert_document_template = "INSERT INTO `sap_documents`(`doc_id`, `doc_type`, `doc_number`, `doc_author`, `doc_date`, `doc_description`) "\
"VALUES(\"%s\", %s, \"%s\", \"%s\", \"%s\", \"%s\")";
char *query_insert_validity_template = "INSERT INTO `sap_validity`(`doc_id`, `val_id`, `val_type`) VALUES(\"%s\",\"%s\",%d) ";
char *query_insert_filelist_template = "INSERT INTO `sap_filelist`(`doc_id`, `file_id`, `file_extension`, `file_description`) VALUES(\"%s\",\"%s\",\"%s\",\"%s\")";
char *query_delete_document_template = "DELETE FROM `sap_documents` WHERE `doc_id` = \"%s\"";


//	валидация файла указанного в параметрах
int validate_xml_file(const char *xml_filename)
{
	xmlDocPtr doc = NULL;
	xmlDocPtr schema_doc = NULL;
	xmlSchemaParserCtxtPtr parser_ctxt = NULL;
	xmlSchemaPtr schema = NULL;
	xmlSchemaValidCtxtPtr valid_ctxt = NULL;
	int is_valid = 0;
	//	Если аргументы не действительны, то выходим.
	check(xml_filename != NULL, "validate_xml_file had invalid input parameters.");
	doc = xmlParseFile(xml_filename);
	check(doc != NULL, "Cannot parse file for validation.");
	schema_doc = xmlReadFile(SCHEMA_FILENAME, NULL, XML_PARSE_NONET);
	check(schema_doc != NULL, "Cannot read schema file.");
	parser_ctxt = xmlSchemaNewDocParserCtxt(schema_doc);
	check(parser_ctxt != NULL, "Cannot create parser context.");
	schema = xmlSchemaParse(parser_ctxt);
	check(schema != NULL, "Cannot create schema.");	
	valid_ctxt = xmlSchemaNewValidCtxt(schema);
	check(valid_ctxt != NULL, "Cannot create validation context.");		
	is_valid = (xmlSchemaValidateDoc(valid_ctxt, doc) == 0);
	xmlSchemaFreeValidCtxt(valid_ctxt);
	xmlSchemaFree(schema);
	xmlSchemaFreeParserCtxt(parser_ctxt);
	xmlFreeDoc(schema_doc);
	xmlFreeDoc(doc);
	return is_valid ? 0 : 1;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	if (valid_ctxt != NULL) 
		xmlSchemaFreeValidCtxt(valid_ctxt);
	if (schema != NULL)
		xmlSchemaFree(schema);
	if (parser_ctxt != NULL)	
		xmlSchemaFreeParserCtxt(parser_ctxt);
	if (schema_doc != NULL)
		xmlFreeDoc(schema_doc);
	if (doc != NULL)
		xmlFreeDoc(doc);
	return -1;
}


//Очистка строки от пустот справа и слева
//Результат: указатель на подстроку в исходной строке
char *trimwhitespace(char *str)
{
	char *end = NULL;
	//	Если аргументы не действительны, то выходим.
	check(str != NULL, "trimwhitespace had invalid input parameters.");
	//Отрезаем пустоту слева
	while(isspace(*str)) str++;
	//Если строка целиком состоит из пробелов, выходим
	if(*str == 0)
		return str;
	//Отрезаем пустоту справа
	end = str + strlen(str) - 1;
	while(end > str && isspace(*end)) end--;
	//Вставляем символ окончания строки
	*(end + 1) = 0;
	return str;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	return NULL;
}

//Очистка от пустот справа и слева и экранирование строки
//Результат: строка новая строка, которая должна быть освобождена
char *clean_escape_xml_content(MYSQL *mysql_con, xmlNode *text_node)
{
	xmlChar *text_node_val = NULL;
	char *escaped_text = NULL;
	char *trimmed_text = NULL;
	//	Если аргументы не действительны, то выходим.
	check((text_node != NULL) && (mysql_con != NULL), "clean_escape_xml_content had invalid input parameters.");
	//Выходим, если узел не текстовый
	check_debug(text_node->type == XML_TEXT_NODE, "Xml node is not of type XML_TEXT_NODE.");
	//Получаем строку-значение узла
	text_node_val = xmlNodeGetContent(text_node);
	//Если не получилось, то выходим
	check(text_node_val != NULL, "Cannot get xml node value.");
	//Обрезаем пустоты справа и слева
	trimmed_text = trimwhitespace((char *)text_node_val);
	check(trimmed_text != NULL, "Cannot trim whitespaces.");
	//Выделяем память для результирующей строки
	size_t len = strlen(trimmed_text);
	escaped_text = calloc(len * 2 + 1, 1);
	//Если не получилось, то выходим
	check_mem(escaped_text);
	//Экранируем символы, не допустимые в SQL-запросах
	check(mysql_real_escape_string(mysql_con, escaped_text, trimmed_text, len) != 0, "Cannot escape text.");
	//Освобождаем память выделенную под текстовый xml-узел
	xmlFree(text_node_val);
	//Возвращаем результат
	return escaped_text;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	if (text_node_val != NULL)
		xmlFree(text_node_val);
	if (escaped_text != NULL)
		free(escaped_text);
	return NULL;
}

struct query_list *parse_validity(MYSQL *mysql_con, xmlNode *node, xmlChar *id)
{
	struct query_list *queries = NULL;
	char *val_id = NULL, *validity_insert = NULL;
	//	Если аргументы не действительны, то выходим.
	check((id != NULL) && (mysql_con != NULL) && (node != NULL), "parse_validity had invalid input parameters.");
	while (node != NULL)
	{
		if (node->type != XML_ELEMENT_NODE)
		{
			node = node->next;
			continue;
		}
		int val_type = 0;
		if (!xmlStrcmp(node->name, (const xmlChar *)"change"))
			val_type = 1;
		else if (!xmlStrcmp(node->name, (const xmlChar *)"cancel"))
			val_type = 2;
		val_id = clean_escape_xml_content(mysql_con, node->xmlChildrenNode);
		check(val_id != NULL, "Error while escaping validity id.");
		validity_insert = calloc(QUERY_BUFFER_SIZE, 1);
		check_mem(validity_insert);
		check(sprintf(validity_insert, query_insert_validity_template, val_id, id, val_type) > 0, "Cannot compose insert validity query.");
		check(query_list_add_query(&queries, validity_insert) == 0, "Cannot compose validity query list.");
		free(validity_insert);
		free(val_id);
		validity_insert = NULL;
		val_id = NULL;
		node = node->next;
	}
	return queries;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	free_query_list(queries);
	if (val_id != NULL)
		free(val_id);
	if (validity_insert != NULL)
		free(validity_insert);
	return NULL;
}

struct query_list *parse_filelists(MYSQL *mysql_con, xmlNode *node, xmlChar *id)
{
	struct query_list *queries = NULL;
	xmlNode *cur_chld = NULL;
	char *file_desc = NULL, *file_ext = NULL, *file_id = NULL, *files_insert = NULL, *file_name = NULL;
	//	Если аргументы не действительны, то выходим.
	check((id != NULL) && (mysql_con != NULL) && (node != NULL), "parse_filelists had invalid input parameters.");
	while(node != NULL)
	{
		if (node->type != XML_ELEMENT_NODE)
		{
			node = node->next;
			continue;
		}
		for (cur_chld = node->children; cur_chld != NULL; cur_chld = cur_chld->next)
		{
			if (cur_chld->type != XML_ELEMENT_NODE)
				continue;
			if (!xmlStrcmp(cur_chld->name, (const xmlChar *)"file_description"))
			{
					file_desc = clean_escape_xml_content(mysql_con, cur_chld->xmlChildrenNode);
					check(file_desc != NULL, "Error while escaping file_desc.");
			}
			else if (!xmlStrcmp(cur_chld->name, (const xmlChar *)"file_name"))
			{
				file_name = clean_escape_xml_content(mysql_con, cur_chld->xmlChildrenNode);
				check(file_name != NULL, "Error while escaping file_name.");
				check(strncmp(file_name, (char *)id, DOC_ID_LENGTH) == 0, "Filename and document id does not match.");
				file_ext = calloc(DOC_FILE_EXT_LENGTH + 1, 1);
				check_mem(file_ext);
				file_id = calloc(DOC_FILE_ID_LENGTH + 1, 1);
				check_mem(file_id);
				strncpy(file_id, file_name + DOC_ID_LENGTH, DOC_FILE_ID_LENGTH);
				char *dot_position = NULL;
				if ((dot_position = strchr(file_name, '.')) != NULL)
					strncpy(file_ext, dot_position + 1, DOC_FILE_EXT_LENGTH);
			}
		}
		check((file_desc != NULL) && (file_name != NULL), "Cannot parse file_list node.");
		files_insert = calloc(QUERY_BUFFER_SIZE, 1);
		check_mem(files_insert);
		check(sprintf(files_insert, query_insert_filelist_template, id, file_id, file_ext, file_desc) > 0, "Cannot compose insert filelist query.");
		check(query_list_add_query(&queries, files_insert) == 0, "Cannot compose filelist query list.");
		free(file_desc);
		free(file_name);
		free(file_ext);
		free(file_id);
		free(files_insert);
		file_desc = NULL;
		file_name = NULL;
		file_ext = NULL;
		file_id = NULL;
		files_insert = NULL;
		node = node->next;
	}
	return queries;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	free_query_list(queries);
	if (file_desc != NULL)
		free(file_desc);
	if (file_ext != NULL)
		free(file_ext);
	if (file_id != NULL)
		free(file_id);
	if (files_insert != NULL)
		free(files_insert);
	if (file_name != NULL)
		free(file_name);
	return NULL;
}

struct query_list *parse_xml_file(MYSQL *mysql_con, const char *xml_file)
{
	xmlDoc *doc = NULL;
	xmlNode *doc_node = NULL, *doc_chld = NULL;
	char *document_insert = NULL, *document_delete = NULL,  *type = NULL, *number = NULL, *author = NULL, *date = NULL, *description = NULL;
	xmlChar *id = NULL;
	struct query_list *queries = NULL, *validities = NULL, *files = NULL;

	LIBXML_TEST_VERSION
	//	Если аргументы не действительны, то выходим.
	check((xml_file != NULL) && (mysql_con != NULL), "parse_xml_filelists had invalid input parameters.");
	doc = xmlReadFile(xml_file, "UTF-8", XML_PARSE_NOBLANKS | XML_PARSE_NONET);
	check(doc != NULL, "Cannot parse xml file.");
	doc_node = xmlDocGetRootElement(doc);
	check(doc_node != NULL, "Cannot get xml root node.");
	for (doc_node = doc_node->children; doc_node != NULL; doc_node = doc_node->next)
	{
		if (doc_node->type != XML_ELEMENT_NODE)
			continue;
		id = xmlGetProp(doc_node, (xmlChar *)"id");
		check(id != NULL, "Cannot get id property.")
		for (doc_chld = doc_node->children; doc_chld != NULL; doc_chld = doc_chld->next)
		{
			if (doc_chld->type != XML_ELEMENT_NODE)
				continue;
			if (!xmlStrcmp(doc_chld->name, (const xmlChar *)"type"))
			{
				type = clean_escape_xml_content(mysql_con, doc_chld->xmlChildrenNode);
				check(type != NULL, "Error while escaping type.")
			}
			else if (!xmlStrcmp(doc_chld->name, (const xmlChar *)"number"))
			{
				number = clean_escape_xml_content(mysql_con, doc_chld->xmlChildrenNode);
				check(number != NULL, "Error while escaping number.");
			}
			else if (!xmlStrcmp(doc_chld->name, (const xmlChar *)"author"))
			{
				author = clean_escape_xml_content(mysql_con, doc_chld->xmlChildrenNode);
				check(author != NULL, "Error while escaping author.");
			}
			else if (!xmlStrcmp(doc_chld->name, (const xmlChar *)"date"))
			{
				date = clean_escape_xml_content(mysql_con, doc_chld->xmlChildrenNode);
				check(date != NULL, "Error while escaping author.");
			}
			else if (!xmlStrcmp(doc_chld->name, (const xmlChar *)"description"))
			{
				if (doc_chld->xmlChildrenNode != NULL)
				{
					description = clean_escape_xml_content(mysql_con, doc_chld->xmlChildrenNode);
					check(description != NULL, "Error while escaping description. %s", id);
				}
				else
					description = calloc(2, 1);
			}
			else if (!xmlStrcmp(doc_chld->name, (const xmlChar *)"validity"))
			{
				validities = parse_validity(mysql_con, doc_chld->children, id);
				check(validities != NULL, "Error while parsing validity node.");
			}
			else if (!xmlStrcmp(doc_chld->name, (const xmlChar *)"file_list"))
			{
				files = parse_filelists(mysql_con, doc_chld->children, id);
				check(files != NULL, "Error while parsing file_list node.");
			}
		}
		check((type != NULL) && (number != NULL) && (author != NULL) && (date != NULL) && (description != NULL) && (files != NULL), "Error while parsing document node.");
		document_delete = calloc(QUERY_BUFFER_SIZE, 1);
		check_mem(document_delete);
		check(sprintf(document_delete, query_delete_document_template, id) > 0, "Cannot compose delete document query.");
		check(query_list_add_query(&queries, document_delete) == 0, "Cannot compose delete document query list.");
		document_insert = calloc(QUERY_BUFFER_SIZE, 1);
		check_mem(document_insert);
		check(sprintf(document_insert, query_insert_document_template, id, type, number, author, date, description) > 0, "Cannot compose insert document query.");
		check(query_list_add_query(&queries, document_insert) == 0, "Cannot compose insert document query list.");
		if (validities != NULL)
			query_list_append(queries, validities);
		query_list_append(queries, files);
		xmlFree(id);
		free(type);
		free(number);
		free(author);
		free(date);
		free(description);
		free(document_insert);
		free(document_delete);
		document_insert = NULL;
		document_delete = NULL;
		id = NULL;
		type = NULL;
		number = NULL;
		author = NULL;
		date = NULL;
		description = NULL;
		validities = NULL;
		files = NULL;
	}
	xmlFreeDoc(doc);
	return queries;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	free_query_list(queries);
	free_query_list(validities);
	free_query_list(files);
	if (doc != NULL)
		xmlFreeDoc(doc);
	if (id != NULL)
		xmlFree(id);
	if (document_delete != NULL)
		free(document_delete);
	if (document_insert != NULL)
		free(document_insert);
	if (type != NULL)
		free(type);
	if (number != NULL)
		free(number);
	if (author != NULL)
		free(author);
	if (date != NULL)
		free(date);
	if (description != NULL)
		free(description);
	return NULL;
}
