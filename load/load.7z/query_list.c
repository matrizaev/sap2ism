#include "dbg.h"
#include "sap2ism.h"

//	функция добавления строки в односвязный список SQL-запросов, если список не существует, то создается
//	параметры: указатель на начало списка и указатель на SQL-запрос
//	результат 0, если удачно
int query_list_add_query(struct query_list **queries, char *str)
{
	struct query_list *temp = NULL;
	//	Если аргументы не действительны, то выходим.
	check(str != NULL, "query_list_add_query had invalid parameters.");
	if (*queries == NULL)
	{
		*queries = malloc(sizeof (struct query_list));
		check_mem(*queries);
		(*queries)->next = NULL;
		(*queries)->query = strdup(str);
		check_mem((*queries)->query);
		return 0;
	}
	temp = *queries;
	while (temp->next != NULL)
		temp = temp->next;
	temp->next = malloc(sizeof (struct query_list));
	check_mem(temp->next);
	temp->next->next = NULL;
	temp->next->query = strdup(str);
	check_mem(temp->next->query);
	return 0;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	if (temp == NULL)
	{
		if (*queries != NULL)
		{
			if ((*queries)->query != NULL)
				free((*queries)->query);
			free(*queries);
			*queries = NULL;
		}
	}
	else
	{
		if (temp->next != NULL)
		{
			if (temp->next->query != NULL)
				free(temp->next->query);
			free(temp->next);
			temp->next = NULL;
		}
	}
	return -1;
}

//	добавление одного односвязного списка SQL-запросов в конец второго
//	результат 0, если удачно
int query_list_append(struct query_list *queries,struct query_list *appends)
{
	//	Если аргументы не действительны, то выходим.
	check((queries != NULL) && (appends != NULL), "query_list_append had invalid parameters.");
	struct query_list *temp = queries;
	while (temp->next != NULL)
		temp = temp->next;
	temp->next = appends;
	return 0;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	return -1;
}

//	освобождение памяти выделенной для односвязного списка SQL-запросов
void free_query_list(struct query_list *queries)
{
	struct query_list *temp;
	while (queries != NULL)
	{
		temp = queries;
		queries = queries->next;
		if (temp->query != NULL)
			free(temp->query);
		free(temp);
	}
}