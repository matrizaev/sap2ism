#include "dbg.h"
#include "sap2ism.h"

void close_mysql_connection(MYSQL *mysql_con)
{
	if (mysql_con != NULL)
		mysql_close(mysql_con);
	return;
}

MYSQL *init_mysql_connection()
{
	MYSQL *mysql_con = NULL;
	mysql_con = mysql_init(NULL);
	check(mysql_con != NULL, "MySQL init failed.");
	check(mysql_real_connect(mysql_con, DATABASE_HOST, DATABASE_USER, DATABASE_PASSWORD, DATABASE_SCHEMA, 3306, NULL, 0) != NULL, "MySQL connect failed.");
	check(mysql_set_character_set(mysql_con, "utf8") == 0, "MySQL set character set failed.");
	return mysql_con;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	close_mysql_connection(mysql_con);
	return NULL;
}

int make_mysql_query(MYSQL *mysql_con, struct query_list *queries)
{
	int query_result = 0, query_sum = 0;
	struct query_list *temp = NULL;
	//	Если аргументы не действительны, то выходим.
	check((queries != NULL) && (mysql_con != NULL), "make_mysql_query had invalid input parameters.");
	for (temp = queries; temp != NULL; temp = temp->next)
	{
		query_result = mysql_query(mysql_con, temp->query);
		if (query_result != 0)
			log_err("Error in query: %s\n\t%s", temp->query, mysql_error(mysql_con));
		query_sum += query_result;
	}
	return query_sum;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	return -1;
}
