#include "dbg.h"
#include <libxml/parser.h>
#include <omp.h>
#include <dirent.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "sap2ism.h"

//	Функция перемещения файла из текущей директории в указанную в параметрах.
//	Результат равен 0, если удачно.
int move_file(const char *file_name, const char *directory)
{
	char *error_path = NULL;
	struct stat sb;
	//	Если аргументы не действительны, то выходим.
	check((file_name != NULL) && (directory != NULL), "move_file had invalid parameters.");
	check(access(file_name, F_OK) == 0, "Cannot access specified file.");
	check(stat(directory, &sb) == 0, "Cannot stat specified directory.");
	check(S_ISDIR(sb.st_mode), "Specified directory is not a directory.");
	check(access(directory, F_OK) == 0, "Cannot access specified directory.");
	error_path = calloc(1, strlen(file_name) + strlen(directory) + 2);
	check_mem(error_path);
	check(strcpy(error_path, directory) != NULL, "Error while composing error directory path.");
	check(strcat(error_path, file_name) != NULL, "Error while composing error directory path.");
	check(rename(file_name, error_path) == 0, "Error while moving file to error directory.");
	log_info("Moving %s to %s directory.", file_name, directory);
	free(error_path);
	return 0;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	if (error_path != NULL)
		free(error_path);
	return -1;
}

//	Функция фильтрации файлов, при получении списка валидных xml-файлов.
//	Файл должен иметь формат имени PRYYMMDDNN.xml.
//	Файл должен соответствовать схеме.
int xml_file_name_filter(const struct dirent *d)
{
	const char *xml_filename_pr_str = "PR";
	const char *xml_filename_xml_str = ".xml";
	const char * xml_filename_template = "%2s%2u%2u%2u%2u%4s";
	char *pr = NULL;
	char *xml = NULL;
	int year = 0;
	int month = 0;
	int day = 0;
	int num = 0;
	const time_t epoch_time = time(NULL);
	struct tm *t = NULL;
	//	Если аргументы не действительны, то выходим.
	check(d != NULL, "xml_file_name_filter had invalid input parameters.");
	check_debug(strlen(d->d_name) == 14, "Wrong filename.");
	pr = calloc(strlen(xml_filename_pr_str) + 1, 1);
	check_mem(pr);
	xml = calloc(strlen(xml_filename_xml_str) + 1, 1);
	check_mem(xml);
	t = localtime(&epoch_time);
	check(t != NULL, "Local time undefined.");
	if (sscanf(d->d_name, xml_filename_template, pr, &year, &month, &day, &num, xml) == 6)
	{
		if (!strcmp(pr, xml_filename_pr_str) && !strcmp(xml, xml_filename_xml_str)&&((t->tm_year - 100) == year) && ((t->tm_mon + 1) == month) && (t->tm_mday == day))
		{
			if (validate_xml_file(d->d_name) == 0)
			{
				free(pr);
				free(xml);
				return 1;
			}
			else
				move_file(d->d_name, ERROR_DIRECTORY);
		}
	}
	debug("Wrong filename.");
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	if (pr != NULL)
		free(pr);
	if (xml != NULL)
		free(xml);
	return 0;
}


int main(int argc, char *argv[])
{
	//	Список имен валидных xml-файлов.
	struct dirent **xml_files = NULL;
	//	Число имен в списке валидных xml-файлов.
	int files_count = 0;
	//	Попытка инициализировать библиотеку libmysqlclient.
	check(mysql_library_init(0, NULL, NULL) == 0, "Init MySQL library failed.");
	//	Инициализация библиотеки libxml2.
	xmlInitParser();
	//	Получение списка валидных xml-файлов.
	files_count = scandir (WORKING_DIRECTORY, &xml_files, xml_file_name_filter, alphasort);
	//	Проверка на наличие файлов.
	check((xml_files != NULL) && (files_count > 0), "No valid files were found.");
	//	Запускаем несколько потоков для обработки файлов.
	#pragma omp parallel for shared(xml_files)
	//	Для каждого файла в списке.
	for (int i = 0; i < files_count; i++)
	{
		//	Подключаемся к базе данных
		MYSQL *mysql_con = init_mysql_connection();
		if (mysql_con != NULL)
		{
			//	Парсим файл и получаем односвязный список SQL-запросов.
			struct query_list *queries = parse_xml_file(mysql_con, xml_files[i]->d_name);
			if (queries != NULL)
			{
				//	В случае, если парсинг удался, выполняем SQL-запросы к базе данных.
				int query_result = make_mysql_query(mysql_con, queries);
				free_query_list(queries);
				//	Если ошибок при выполнении запросов нет, удаляем файл, иначе перемещаем в директорию для ошибок.
				if (query_result == 0)
					unlink(xml_files[i]->d_name);
				else
					move_file(xml_files[i]->d_name, ERROR_DIRECTORY);
				free(xml_files[i]);
			}
			else
			{
				//	В случае ошибок парсинга перемещаем файл в директорию для ошибок.
				log_err("Error parsing xml file %s.", xml_files[i]->d_name);
				move_file(xml_files[i]->d_name, ERROR_DIRECTORY);
			}
			//	Cигнализируем библиотеке libmysqlclient о завершении потока.
			mysql_thread_end();
			close_mysql_connection(mysql_con);
		}
		else
		{
			free(xml_files[i]);
			log_err("Cannot connect to database.");
		}
	}
	//	Освобождаем занятые ресурсы.
	free(xml_files);
	//	Сигнализируем о завершении библиотекам libmysqlclient и libxml2
	mysql_library_end();
	xmlCleanupParser();
	return 0;
error:
	//	В случай ошибки, освобождаем занятые ресуры и возвращаем признак ошибки.
	if (xml_files != NULL)
	{
		for (int i = 0; i < files_count; i++)
			if (xml_files[i] != NULL)
				free(xml_files[i]);
		free(xml_files);
	}
	mysql_library_end();
	xmlCleanupParser();
	return -1;
}
