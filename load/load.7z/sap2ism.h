#ifndef SAP2ISM_H
#define SAP2ISM_H

#include <mysql.h>
#include <stdlib.h>

#define SCHEMA_FILENAME "scheme.xsd"
#define DATABASE_HOST "192.168.97.85"
#define DATABASE_USER "root"
#define DATABASE_PASSWORD "5Gjy$BUe"
#define DATABASE_SCHEMA "sap2ism"
#define ERROR_DIRECTORY "./errors/"
#define WORKING_DIRECTORY "."
#define QUERY_BUFFER_SIZE 4096
#define DOC_ID_LENGTH 18
#define DOC_FILE_ID_LENGTH 2
#define DOC_FILE_EXT_LENGTH 4
#define DOC_FILE_DESC_LENGTH 50

//	Тип односвязного списка для хранения SQL запросов.
struct query_list
{
	char *query;
	struct query_list *next;
};

extern MYSQL *init_mysql_connection();

extern void close_mysql_connection(MYSQL *mysql_con);

//	Функция валидации указанного в параметрах xml-файла.
//	Результат 0, если файл валидный.
extern int validate_xml_file(const char *xml_filename);

//	Функция парсинга xml-файла, возвращающая односвязный список SQL-запросов.
//	Параметры подключения к базе данных нужны для экранирования символов в SQL-запросах, параметр xml_file содержит массив имен валидных xml-файлов.
//	Память выделенная для односвязного списка SQL-запросов должна быть освобождена.
//	Результат равен NULL, в случае ошибки.
extern struct query_list *parse_xml_file(MYSQL *mysql_con, const char *xml_file);

//	Функция добавления строки в односвязный список SQL-запросов, если список не существует, то создается.
//	Параметры: указатель на начало списка и указатель на SQL-запрос.
//	Результат равен 0, если удачно.
extern int query_list_add_query(struct query_list **queries, char *str);

//	Добавление одного односвязного списка SQL-запросов в конец второго.
//	Результат равен 0, если удачно.
extern int query_list_append(struct query_list *queries,struct query_list *appends);

//	Функция выполняющая SQL-запросы из односвязного списка.
//	Параметры подключения к базе и односвязный список SQL-запросов.
//	Результат равен 0, если удачно.
extern int make_mysql_query(MYSQL *mysql_con, struct query_list *queries);

//	Освобождение памяти выделенной для односвязного списка SQL-запросов.
extern void free_query_list(struct query_list *queries);

#endif // SAP2ISM_H
